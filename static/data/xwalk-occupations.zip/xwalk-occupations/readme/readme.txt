Occupation Crosswalks

Author: Joonas Tuhkuri

Description: This folder contains occupation crosswalks for data in Finland.

The inputs are occupation codes (2001 and 2010 versions), and the outputs are the harmonized occupation codes (2010new).

The crosswalk file xw_occ01_occ10new.dta maps 2001 occupation codes to a harmonized occupation code, 2010new.

The crosswalk file xw_occ10_occ10new.dta maps 2010 occupation codes to a harmonized occupation code, 2010new.

The Finnish occupation data uses the 2010 classification from 2010 onwards and the 2001 classification in 1995, 2000, 2004 - 2009. Occupation data are sometimes available for 1990 ja 1993 with the 1980 occupation classification.

The sources for the occupation crosswalk are the Statistics Finland classification manuals. The crosswalk is manually constructed for each occupation.
