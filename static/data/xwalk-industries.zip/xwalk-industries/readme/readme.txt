Industry Crosswalks

Author: Joonas Tuhkuri

Description: This folder contains industry crosswalks for data in Finland.

The crosswalks help harmonize the industries over 1987–2018 to a modified 95-new industry classification separately at the 2 and 3-digit levels.

The inputs are industry codes, and the outputs are the harmonized industry codes (95new)

The classification of industries has changed over the years:
toimiala_1_08_s (TOL2008) from 2007 onwards 
toimiala_1_02_s (TOL2002) years 2001 to 2006 
toimiala_1_00_s (TOL95, second revised edition) years 1998 to 2000 
toimiala_1_95_s (TOL95) years 1993 to 1997 
toimiala_1_88_s (TOL88) years 1987 to 1992 

The sources for the occupation crosswalk are the Statistics Finland classification manuals. The crosswalk is manually constructed for each industry.
