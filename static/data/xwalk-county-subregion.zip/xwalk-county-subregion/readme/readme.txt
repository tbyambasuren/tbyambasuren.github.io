Country-Subregion Crosswalks

Author: Joonas Tuhkuri

Description: This folder contains county-subregion crosswalks for data in Finland.

The crosswalk files help harmonize Finnish county classifications into three distinct subregion classifications (94, 01, and 08).

The inputs are the county codes, and the outputs are the subregion code.

The crosswalk files are defined for ranges from the year in the filename until the next available file year. For example, kunta87_sk94 maps counties in 1987, 1988, 1989, 1990, and 1991 to subregions in 1994, and kunta92_ski94 maps counties in 1992 to subregions in 1994. 

The sources for the crosswalk are the county and subregion classification files provided by Statistics Finland.